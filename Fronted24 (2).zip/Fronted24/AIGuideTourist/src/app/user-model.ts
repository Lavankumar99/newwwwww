export class UserModel {
    fullName:string='';
    email:string='';
    password:string='';
    address:string='';
    mobileNumber:string='';

    // constructor( fullName:string,email:string,password:string,address:string,mobileNumber:string){
    //     this.email=email;
    //     this.address=address;
    //     this.fullName=fullName;
    //     this.mobileNumber=mobileNumber;
    //     this.password=password;
    // }
    constructor(){}

}
