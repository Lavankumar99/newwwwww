import { Adminmodel } from './adminmodel';

describe('Adminmodel', () => {
  it('should create an instance', () => {
    expect(new Adminmodel()).toBeTruthy();
  });
});
