import { Component } from '@angular/core';

@Component({
  selector: 'app-allimagesuser',
  templateUrl: './allimagesuser.component.html',
  styleUrl: './allimagesuser.component.css'
})
export class AllimagesuserComponent {

}
